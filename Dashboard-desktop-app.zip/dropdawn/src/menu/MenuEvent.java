package menu;

/**
 *
 * @author KAPAKA
 */
public interface MenuEvent {

    public void selected(int index, int subIndex);
}
